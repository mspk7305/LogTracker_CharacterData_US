LogTracker_CharacterData_US = { ['_VERSION'] = 1 };

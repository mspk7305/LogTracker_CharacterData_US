# LogTracker_CharacterData_US

## [1.0.4-202210260902](https://github.com/ForsakenNGS/LogTracker_CharacterData_US/tree/1.0.4-202210260902) (2022-10-26)
[Full Changelog](https://github.com/ForsakenNGS/LogTracker_CharacterData_US/compare/1.0.4-202210190901...1.0.4-202210260902) [Previous Releases](https://github.com/ForsakenNGS/LogTracker_CharacterData_US/releases)

- Addon data update 2022-10-26 09:02  
